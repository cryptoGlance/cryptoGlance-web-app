   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="shortcut icon" href="favicon.png">
      <title>RigWatch - Dashboard</title>
      <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- HubSpot / messenger (https://github.com/HubSpot/messenger) styles -->
      <link href="css/messenger.css" rel="stylesheet">
      <link href="css/messenger-spinner.css" rel="stylesheet">
      <link href="css/messenger-theme-flat.css" rel="stylesheet">
      <!-- Glyph Icon Font from WebHostingHub (http://www.webhostinghub.com/glyphs/) styles -->
      <link href="css/whhg.css" rel="stylesheet">
      <!-- Custom RigWatch styles -->
      <link href="css/rigwatch-base.css" rel="stylesheet">
      
      <base href="http://localhost/rigwatch/">
      <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
      <![endif]-->
   </head>