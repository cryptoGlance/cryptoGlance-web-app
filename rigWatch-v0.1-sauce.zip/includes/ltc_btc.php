<?php

$res = file_get_contents('https://btc-e.com/api/2/ltc_btc/ticker');

echo $res;

?>