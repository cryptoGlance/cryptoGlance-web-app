      <div id="footer">
         <div class="container well well-sm">
            Licensed under GPLv2 - <a href="https://github.com/scar45/rigwatch" rel="external">Source on Github <i class="icon icon-github"></i></a> - Long live crypto-currency!
         </div>
      </div>
                  
      <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/messenger.min.js"></script>
      <script src="js/messenger-theme-flat.js"></script>
      <script src="js/currency.js"></script>
      <script src="js/rigwatch-ui.js"></script>
   </body>
</html>